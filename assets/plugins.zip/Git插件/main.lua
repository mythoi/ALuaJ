require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "autotheme"
import "java.io.File"
curProjectPath,curProjectName,curFileName=...
import "layout"
activity.setTitle("Git插件");
activity.setTheme(autotheme())
activity.setContentView(loadlayout(layout))


mThread=thread(function()

  require "import"
  import "android.app.*"
  import "android.os.*"
  import "android.widget.*"
  import "android.view.*"
  import "layout"
  import "java.io.File"
  import "org.eclipse.jgit.lib.Repository"
  import "org.eclipse.jgit.storage.file.FileRepositoryBuilder"
  import "org.eclipse.jgit.api.Git"
  import "org.eclipse.jgit.transport.*"

  function writeFile(path,content)
    f=File(tostring(File(tostring(path)).getParentFile())).mkdirs()
    io.open(tostring(path),"w"):write(tostring(content)):close()
  end

  --克隆仓库
  function cloneRepository(url,localPath)
    if not pcall(function()
      print("开始下载")
      git = Git.cloneRepository()
      .setURI(url)
      .setDirectory(File(localPath))
      .setCloneAllBranches(true)
      .call()
      print("下载完成")
      call("hideProgress")
    end) then
      print("克隆失败，本地目录已存在或远程仓库不存在")
      call("hideProgress")
    end
  end

  --提交代码
  function commit(paramTable)
    projectURL=paramTable.localPath .."/.git"
    fileCache=activity.getExternalCacheDir()
    LuaUtil.rmDir(fileCache) 
    print("开始提交")
    if not pcall(function()
      if not File(paramTable.localPath.."/.git").exists() then
        git = Git.cloneRepository()
        .setURI(paramTable.url)
        .setDirectory(fileCache)
        .call() 
        LuaUtil.copyDir(fileCache.getAbsolutePath().."/.git",paramTable.localPath.."/.git")
      end 
      if not File(paramTable.localPath.."/.gitignore").exists() then
        writeFile(paramTable.localPath.."/.gitignore","/bin/")--添加忽略文件
      end

      git=Git.open(File(projectURL))

      --[[    git.pull().call()
    status=git.status().call()
    if (status.hasUncommittedChanges() == false) then
      print("无已修改文件")
      call("hideProgress")
      return
    end ]]

      git.add().addFilepattern(".").call();
      git.commit().setMessage(paramTable.msg).call();

      pull= git.pull()
      pull.setCredentialsProvider(UsernamePasswordCredentialsProvider(paramTable.user, paramTable.pw))
      pull.call();

      push= git.push() 

      push.setCredentialsProvider(UsernamePasswordCredentialsProvider(paramTable.user, paramTable.pw))
      push.call();

      LuaUtil.rmDir(File(projectURL))--提交完成可删除.git目录，
      print("提交成功")
    end) then 
      LuaUtil.rmDir(File(projectURL))--提交失败可删除.git目录，  
      print("提交失败，仓库url错误或账号密码错误")
      call("hideProgress")
    end
    call("hideProgress")
    if git ~= nil then 
      git.close();
    end
  end
end)

function showProgress()

  progressBar.setVisibility(View.VISIBLE)

end

function hideProgress()

  progressBar.setVisibility(View.GONE)

end


clone.onClick=function(v)
  url= urlEdit.text
  localPath= localPathEdit.text
  if url=="" or localPath=="" then
    print("所填项不能为空")
    return
  end
  activity.setSharedData(curProjectName,url)
  showProgress()
  call(mThread,"cloneRepository",url,localPath) 
end



--输入对话框
InputLayout={
  LinearLayout;
  orientation="vertical";
  Focusable=true,
  FocusableInTouchMode=true,
  {
    TextView;
    textSize="15sp",
    layout_marginTop="10dp";
    layout_marginLeft="3dp",
    layout_width="80%w";
    layout_gravity="center",
    text="Github账号:";
  };
  {
    EditText;
    layout_marginTop="5dp";
    layout_width="80%w";
    layout_gravity="center",
    text=activity.getSharedData("user","");
    id="userEdit",
  };
  {
    TextView;
    textSize="15sp",
    layout_marginTop="10dp";
    layout_marginLeft="3dp",
    layout_width="80%w";
    layout_gravity="center",
    text="Github密码:";
  };
  {
    EditText;
    layout_marginTop="5dp";
    layout_width="80%w";
    layout_gravity="center",
    text=activity.getSharedData("pw","");
    InputType=0x00000081;
    id="pwEdit";
  };
  {
    TextView;
    textSize="15sp",
    layout_marginTop="10dp";
    layout_marginLeft="3dp",
    layout_width="80%w";
    layout_gravity="center",
    text="备注信息:";
  };
  {
    EditText;
    layout_marginTop="5dp";
    layout_width="80%w";
    layout_gravity="center",
    id="msgEdit";
  };
};

commit.onClick=function(v) 
  alert=AlertDialog.Builder(this)
  .setTitle("提交到Github")
  .setView(loadlayout(InputLayout))
  .setPositiveButton("提交",{onClick=function(v) 
      paramTable={} 
      paramTable.url= urlEdit.text
      paramTable.localPath= File(localPathEdit.text).getAbsolutePath()
      paramTable.user=userEdit.text
      paramTable.pw=pwEdit.text
      paramTable.msg=msgEdit.text
      if paramTable.url=="" or paramTable.localPath=="" or paramTable.user=="" or paramTable.pw=="" or paramTable.msg=="" then
        print("所填项不能为空")
        return
      end
      activity.setSharedData(curProjectName,paramTable.url)
      activity.setSharedData("user",paramTable.user)
      activity.setSharedData("pw",paramTable.pw)
      showProgress()
      call(mThread,"commit",paramTable) 
    end})
  .setNegativeButton("取消",nil)
  .show()
end



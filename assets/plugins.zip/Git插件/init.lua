appname="Git插件"
appver="1.0"
packagename="com.androluaJ.git"
theme="Theme_Holo_Light"
developer=""
description="Git版本控制插件(一键克隆，一键提交)"
debugmode=true